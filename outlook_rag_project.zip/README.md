# Outlook Email Question RAG (LangChain + Pinecone + Open-Source LLM)

This project builds a Retrieval-Augmented Generation (RAG) pipeline on top of
Outlook emails saved as `.msg` files. It:

- Reads `.msg` files from a local folder
- Extracts question-like sentences
- Stores them in a Pinecone vector index
- At query time, checks if a new question is a duplicate
- If not duplicate, answers using RAG with an open-source LLM via Ollama

## Folder Structure

```text
outlook_rag_project/
  README.md
  requirements.txt
  app/
    __init__.py
    config.py
    dataloader.py
    embeddings.py
    vector_store.py
    ingest.py
    search.py
    cli.py
```

## Requirements

- Python 3.9+
- Pinecone account + API key
- Ollama installed locally with a model pulled (e.g. `llama3`)
- Outlook emails exported as `.msg` files

## Setup

1. Create and activate a virtual environment (recommended).
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Create a `.env` file in the root (`outlook_rag_project/`):

   ```env
   PINECONE_API_KEY=your_pinecone_key
   PINECONE_INDEX_NAME=outlook-questions-index
   PINECONE_CLOUD=aws
   PINECONE_REGION=us-east-1

   EMAIL_MSG_DIR=D:\Outlook_Questions\MSG_Files

   OLLAMA_BASE_URL=http://localhost:11434
   OLLAMA_MODEL=llama3

   SIMILARITY_THRESHOLD=0.85
   TOP_K=3
   ```

4. Make sure Ollama is running and a model is available, for example:

   ```bash
   ollama pull llama3
   ```

## Usage

### 1. Ingest `.msg` Emails

Place your `.msg` email files in the folder specified by `EMAIL_MSG_DIR`
in `.env`.

Then run:

```bash
python -m app.ingest
```

This will:

- Load `.msg` files
- Extract questions
- Upsert them into Pinecone

### 2. Ask Questions (Duplicate + RAG via CLI)

```bash
python -m app.cli
```

- Choose option `1` to run ingestion (if not done already)
- Choose option `2` to type a question:
  - If a similar question exists above the threshold, it will be marked
    as duplicate and returned with metadata.
  - Otherwise, RAG will answer using the email-derived knowledge base.

## Integration with RPA / External Systems

You can import and use the main entry point in `search.py` from any
external orchestrator (UiPath, Automation Anywhere, Power Automate
via HTTP, etc.). For example:

```python
from app.search import handle_question

response = handle_question("What is the estimated time for Project1?")
print(response)
```

Wrap this in a FastAPI service, or call it directly in your Python-based
automations to build an enterprise-ready duplicate detection + RAG Q&A
system on top of Outlook emails.
