from typing import Dict, Any

from langchain_community.chat_models import ChatOllama
from langchain.chains import RetrievalQA

from .config import (
    OLLAMA_BASE_URL,
    OLLAMA_MODEL,
    SIMILARITY_THRESHOLD,
    TOP_K,
)
from .embeddings import get_embeddings
from .vector_store import get_vector_store

_embeddings = get_embeddings()
_vectorstore = get_vector_store()

_llm = ChatOllama(
    base_url=OLLAMA_BASE_URL,
    model=OLLAMA_MODEL,
    temperature=0.0,
)

_retriever = _vectorstore.as_retriever(search_kwargs={"k": 5})
_rag_chain = RetrievalQA.from_chain_type(
    llm=_llm,
    retriever=_retriever,
    return_source_documents=True,
)

def find_duplicate_question(
    question: str,
    similarity_threshold: float = SIMILARITY_THRESHOLD,
    k: int = TOP_K,
) -> Dict[str, Any]:
    results = _vectorstore.similarity_search_with_score(question, k=k)

    if not results:
        return {"is_duplicate": False, "best_match": None}

    best_doc, best_score = results[0]

    if best_score >= similarity_threshold:
        return {
            "is_duplicate": True,
            "similarity_score": float(best_score),
            "best_match": {
                "question": best_doc.page_content,
                "metadata": best_doc.metadata,
            },
        }

    return {
        "is_duplicate": False,
        "similarity_score": float(best_score),
        "best_match": {
            "question": best_doc.page_content,
            "metadata": best_doc.metadata,
        },
    }

def answer_with_rag(question: str) -> Dict[str, Any]:
    result = _rag_chain.invoke({"query": question})
    answer = result["result"]
    source_docs = result.get("source_documents", [])

    sources = [
        {
            "question": doc.page_content,
            "metadata": doc.metadata,
        }
        for doc in source_docs
    ]

    return {
        "answer": answer,
        "sources": sources,
    }

def handle_question(question: str) -> Dict[str, Any]:
    dup_info = find_duplicate_question(question)

    if dup_info["is_duplicate"]:
        return {
            "duplicate": True,
            "message": "Similar question already exists.",
            "similarity_score": dup_info["similarity_score"],
            "existing_question": dup_info["best_match"]["question"],
            "existing_metadata": dup_info["best_match"]["metadata"],
        }

    rag_result = answer_with_rag(question)

    return {
        "duplicate": False,
        "message": "No close duplicate found. Answering using RAG over existing emails.",
        "similarity_score": dup_info.get("similarity_score"),
        "closest_existing_question": dup_info["best_match"]["question"]
        if dup_info.get("best_match")
        else None,
        "answer": rag_result["answer"],
        "sources": rag_result["sources"],
    }
