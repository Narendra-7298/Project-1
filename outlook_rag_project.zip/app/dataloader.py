import os
import re
from typing import List
import extract_msg
from langchain_core.documents import Document

def extract_questions_from_text(text: str) -> List[str]:
    """
    Naive question extractor:
    - Split by newline / period
    - Keep segments ending with '?'
    """
    if not text:
        return []

    candidates = re.split(r"[\n\.]", text)
    questions = [c.strip() for c in candidates if c.strip().endswith("?")]
    return questions

def load_msg_files(root_dir: str) -> List[str]:
    """Recursively find all .msg files under a root directory."""
    msg_paths: List[str] = []
    for base, _, files in os.walk(root_dir):
        for f in files:
            if f.lower().endswith(".msg"):
                msg_paths.append(os.path.join(base, f))
    return msg_paths

def build_documents_from_msg_files(msg_dir: str) -> List[Document]:
    """
    For each .msg file:
    - Read subject + body
    - Extract question sentences
    - Create a LangChain Document per question
    """
    docs: List[Document] = []
    msg_paths = load_msg_files(msg_dir)
    print(f"Found {len(msg_paths)} .msg files in {msg_dir}")

    for path in msg_paths:
        try:
            msg = extract_msg.Message(path)
            subject = msg.subject or ""
            body = msg.body or ""

            full_text = subject + "\n" + body
            questions = extract_questions_from_text(full_text)

            for q in questions:
                if not q:
                    continue
                metadata = {
                    "file_path": path,
                    "subject": subject,
                    "source": "outlook_msg",
                }
                docs.append(Document(page_content=q, metadata=metadata))

        except Exception as e:
            print(f"Error reading {path}: {e}")

    return docs
