from typing import Optional
from pinecone import Pinecone, ServerlessSpec
from langchain_pinecone import PineconeVectorStore

from .config import (
    PINECONE_API_KEY,
    PINECONE_INDEX_NAME,
    PINECONE_CLOUD,
    PINECONE_REGION,
)
from .embeddings import get_embeddings

_VECTORSTORE: Optional[PineconeVectorStore] = None

def _get_or_create_pinecone_index(emb_dim: int):
    pc = Pinecone(api_key=PINECONE_API_KEY)
    existing = [idx["name"] for idx in pc.list_indexes().indexes]
    if PINECONE_INDEX_NAME not in existing:
        pc.create_index(
            name=PINECONE_INDEX_NAME,
            dimension=emb_dim,
            metric="cosine",
            spec=ServerlessSpec(cloud=PINECONE_CLOUD, region=PINECONE_REGION),
        )
        print(f"Created Pinecone index: {PINECONE_INDEX_NAME}")
    else:
        print(f"Using existing Pinecone index: {PINECONE_INDEX_NAME}")
    return pc.Index(PINECONE_INDEX_NAME)

def get_vector_store() -> PineconeVectorStore:
    """Singleton-style accessor for PineconeVectorStore."""
    global _VECTORSTORE
    if _VECTORSTORE is not None:
        return _VECTORSTORE

    if not PINECONE_API_KEY:
        raise RuntimeError("PINECONE_API_KEY is not set.")

    embeddings = get_embeddings()
    test_vec = embeddings.embed_query("test question")
    emb_dim = len(test_vec)

    index = _get_or_create_pinecone_index(emb_dim)
    _VECTORSTORE = PineconeVectorStore(
        index=index,
        embedding=embeddings,
        text_key="text",
    )
    return _VECTORSTORE
