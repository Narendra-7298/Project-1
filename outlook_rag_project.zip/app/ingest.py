from .config import EMAIL_MSG_DIR
from .dataloader import build_documents_from_msg_files
from .embeddings import get_embeddings
from .vector_store import get_vector_store
import os

def run_ingestion():
    if not EMAIL_MSG_DIR or not os.path.isdir(EMAIL_MSG_DIR):
        raise RuntimeError(f"EMAIL_MSG_DIR not valid: {EMAIL_MSG_DIR}")

    print(f"Loading .msg files from: {EMAIL_MSG_DIR}")
    docs = build_documents_from_msg_files(EMAIL_MSG_DIR)
    print(f"Extracted {len(docs)} question documents.")

    if not docs:
        print("No question-like sentences found. Nothing to ingest.")
        return

    embeddings = get_embeddings()
    _ = embeddings.embed_query("init test")

    vectorstore = get_vector_store()
    print("Upserting documents into Pinecone...")
    vectorstore.add_documents(docs)
    print("Ingestion complete ✅")


if __name__ == "__main__":
    run_ingestion()
