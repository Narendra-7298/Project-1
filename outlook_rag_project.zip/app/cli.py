from pprint import pprint
from .ingest import run_ingestion
from .search import handle_question

def main():
    print("Outlook MSG RAG - CLI")
    print("1) Run ingestion (index .msg questions)")
    print("2) Ask a question (duplicate check + RAG)")
    print("q) Quit")

    while True:
        choice = input("\nChoose an option (1/2/q): ").strip().lower()
        if choice == "1":
            run_ingestion()
        elif choice == "2":
            q = input("Enter your question: ").strip()
            if not q:
                print("Empty question, try again.")
                continue
            resp = handle_question(q)
            pprint(resp)
        elif choice == "q":
            print("Exiting CLI.")
            break
        else:
            print("Invalid choice, please enter 1, 2 or q.")


if __name__ == "__main__":
    main()
